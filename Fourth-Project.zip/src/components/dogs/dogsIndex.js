import React from 'react';
import Axios from 'axios';

class DogsIndex extends React Component {
  state = {
    dogs: {}
  }


  render() {
    return(

    )
  }
}
