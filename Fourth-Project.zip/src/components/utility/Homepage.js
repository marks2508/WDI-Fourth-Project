import React from 'react';

const Homepage = () => {
  return (
    <div>
      <img className="puppy" src="http://dogtraining.com.au/wp-content/uploads/2016/11/54_2383_Cute-Puppies-puppies-16094619-1280-800.jpg" />
    </div>
  );
};

export default Homepage;
